import os
exec(open('./LatestMoaiUpload.py').read(),globals())









